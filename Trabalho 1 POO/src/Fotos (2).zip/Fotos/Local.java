package Fotos;

public class Local {
    String cidade;
    Estado estado;
}
