package Fotos;

public class Area {
    String descricao;
}
