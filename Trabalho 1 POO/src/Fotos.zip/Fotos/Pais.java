package Fotos;

public class Pais {
    private String nome;
    private String sigla;

    public String getNome() {
        return nome;
    }

    public String getSigla() {
        return sigla;
    }
}
