package Fotos;

public class Estado {
    String nome;
    String sigla;
    Pais pais;
}
